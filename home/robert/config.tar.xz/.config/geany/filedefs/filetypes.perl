[build-menu]
EX_01_LB=Get Docs
EX_01_CM=perldoc %w
EX_01_WD=
