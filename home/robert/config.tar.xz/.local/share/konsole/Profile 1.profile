[Appearance]
ColorScheme=WhiteOnBlack
Font=DejaVu Sans Mono,14,-1,5,400,0,0,0,0,0,0,0,0,0,0,1
UseFontBrailleChararacters=false

[Cursor Options]
CursorShape=0

[General]
Name=Profile 1
Parent=FALLBACK/
TerminalColumns=80
TerminalRows=24
